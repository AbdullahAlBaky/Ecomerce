<!-- Footer -->
<footer class="bg-dark text-white text-center p-3 mt-5" style="margin-left:230px;">
    <p>© 2026 Blood Donation System | Developed by Urbi😎</p>
</footer>

</div> <!-- content end -->
</div> <!-- flex end -->